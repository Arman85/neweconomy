<footer class="footer">
	<div class="container">
		<span class="text-muted">Footer</span>
	</div>
</footer>