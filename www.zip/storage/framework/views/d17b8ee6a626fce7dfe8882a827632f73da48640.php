<!-- Business Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('business_id', 'Business Id:'); ?>

    <?php echo Form::select('business_id', App\Models\Admin\Business::dropdown(), $businessId, ['class' => 'form-control']); ?>

</div>

<!-- Year Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('year', 'Year:'); ?>

    <?php echo Form::text('year', null, ['class' => 'form-control']); ?>

</div>

<!-- If Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('if', 'If:'); ?>

    <?php echo Form::text('if', null, ['class' => 'form-control']); ?>

</div>

<!-- P Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('p', 'P:'); ?>

    <?php echo Form::text('p', null, ['class' => 'form-control']); ?>

</div>

<!-- As Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('as', 'As:'); ?>

    <?php echo Form::text('as', null, ['class' => 'form-control']); ?>

</div>

<!-- I Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('i', 'I:'); ?>

    <?php echo Form::text('i', null, ['class' => 'form-control']); ?>

</div>

<!-- Z Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('z', 'Z:'); ?>

    <?php echo Form::text('z', null, ['class' => 'form-control']); ?>

</div>

<!-- Ef Fin Field -->
<!-- <div class="form-group col-sm-6">
    <?php echo Form::label('ef_fin', 'Ef Fin:'); ?>

    <?php echo Form::text('ef_fin', null, ['class' => 'form-control']); ?>

</div> -->

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('indicators.index'); ?>" class="btn btn-default">Cancel</a>
</div>
