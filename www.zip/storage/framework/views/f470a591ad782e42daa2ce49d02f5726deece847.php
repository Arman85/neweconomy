<li class="<?php echo e(Request::is('businesses*') ? 'active' : ''); ?>">
    <a href="<?php echo route('admin.businesses.index'); ?>"><i class="fa fa-edit"></i><span>Businesses</span></a>
</li>

<li class="<?php echo e(Request::is('regions*') ? 'active' : ''); ?>">
    <a href="<?php echo route('regions.index'); ?>"><i class="fa fa-edit"></i><span>Regions</span></a>
</li>

<li class="<?php echo e(Request::is('indicators*') ? 'active' : ''); ?>">
    <a href="<?php echo route('indicators.index'); ?>"><i class="fa fa-edit"></i><span>Indicators</span></a>
</li>

<li class="<?php echo e(Request::is('indicatorForRegions*') ? 'active' : ''); ?>">
    <a href="<?php echo route('indicatorForRegions.index'); ?>"><i class="fa fa-edit"></i><span>Indicator For Regions</span></a>
</li>

<li class="<?php echo e(Request::is('recommendations*') ? 'active' : ''); ?>">
    <a href="<?php echo route('recommendations.index'); ?>"><i class="fa fa-edit"></i><span>Recommendations</span></a>
</li>

