<table class="table table-responsive" id="indicators-table">
    <thead>
        <tr>
            <th>Business</th>
            <th>Year</th>
            <th>If</th>
            <th>P</th>
            <th>As</th>
            <th>I</th>
            <th>Z</th>
            <th>Ef Fin</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $indicators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $indicator->business->name; ?></td>
            <td><?php echo $indicator->year; ?></td>
            <td><?php echo $indicator->if; ?></td>
            <td><?php echo $indicator->p; ?></td>
            <td><?php echo $indicator->as; ?></td>
            <td><?php echo $indicator->i; ?></td>
            <td><?php echo $indicator->z; ?></td>
            <td><?php echo $indicator->ef_fin; ?> <a href="<?php echo route('indicators.calculate', [$indicator->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-refresh"></i></a></td>
            <td>
                <?php echo Form::open(['route' => ['indicators.destroy', $indicator->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('indicators.show', [$indicator->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('indicators.edit', [$indicator->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>