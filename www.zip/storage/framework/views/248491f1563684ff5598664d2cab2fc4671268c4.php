<table class="table table-responsive" id="businesses-table">
    <thead>
        <tr>
            <th>Name</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>Description</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $business->name; ?></td>
            <td><?php echo $business->latitude; ?></td>
            <td><?php echo $business->longitude; ?></td>
            <td><?php echo $business->description; ?></td>
            <td>
                <?php echo Form::open(['route' => ['admin.businesses.destroy', $business->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('admin.businesses.show', [$business->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('admin.businesses.edit', [$business->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>

                    <a href="<?php echo route('indicators.create', ['business_id' => $business->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-signal"></i></a>
                    

                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>