<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" >
	<title>Neweconomy | <?php echo $__env->yieldContent('title'); ?></title>
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/sticky-footer.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/mystyles.css')); ?>">
	
	<!-- include Leaflet map css -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/leaflet.css')); ?>">
	<link rel="stylesheet" type="text/css" href="http://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/0.4.0/MarkerCluster.css" />
    <link rel="stylesheet" type="text/css" href="http://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/0.4.0/MarkerCluster.Default.css" />

    <!-- jquery -->
    <script src="<?php echo e(asset('assets/js/jquery-3.3.1.min.js')); ?>"></script>
    <!-- include Leaflet map js -->
    <!-- <script type='text/javascript' src='http://cdn.leafletjs.com/leaflet/v0.7.7/leaflet.js'></script>
    <script type='text/javascript' src='http://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/0.4.0/leaflet.markercluster.js'></script> -->

    <!--yandex maps -->
    <script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>
    <!-- <script src="<?php echo e(asset('assets/js/clusterer_icon_hover.js')); ?>" type="text/javascript"></script> -->
</head>
<body>
	<?php echo $__env->make('frontend.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->yieldContent('content'); ?>

	<?php echo $__env->make('frontend.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/myscript.js')); ?>"></script>

    <!-- Other -->
	<script>
		$(document).ready(function (){
			<?php echo $__env->yieldContent('scripts'); ?>;

		});
	</script>
</body>
</html>