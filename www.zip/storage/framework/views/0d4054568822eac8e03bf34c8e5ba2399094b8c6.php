<!-- Region Field -->
<div class="form-group col-sm-4">
    <?php echo Form::label('region', 'Region:'); ?>

    <?php echo Form::select('region_id', App\Models\Region::dropdown(), null, ['class' => 'form-control']); ?>

</div>

<!-- Name Field -->
<div class="form-group col-sm-4">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Latitude Field -->
<div class="form-group col-sm-4">
    <?php echo Form::label('latitude', 'Latitude:'); ?>

    <?php echo Form::text('latitude', null, ['class' => 'form-control']); ?>

</div>

<!-- Longitude Field -->
<div class="form-group col-sm-4">
    <?php echo Form::label('longitude', 'Longitude:'); ?>

    <?php echo Form::text('longitude', null, ['class' => 'form-control']); ?>

</div>

<!-- Description Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('description', 'Description:'); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('admin.businesses.index'); ?>" class="btn btn-default">Cancel</a>
</div>
