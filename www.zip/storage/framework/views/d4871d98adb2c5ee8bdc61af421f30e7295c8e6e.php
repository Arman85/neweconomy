<!-- Type Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('type', 'Type:'); ?>

    <?php echo Form::text('type', null, ['class' => 'form-control']); ?>

</div>

<!-- Desc Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('desc', 'Desc:'); ?>

    <?php echo Form::textarea('desc', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('recommendations.index'); ?>" class="btn btn-default">Cancel</a>
</div>
